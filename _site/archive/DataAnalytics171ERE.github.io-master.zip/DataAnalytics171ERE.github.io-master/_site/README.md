# DataAnalytics171ERE.github.io
Web Page Data Analytics 2017 I 
Members : 
* Peinado Rodriguez Enrique Alexis 
* Huaranga Junco Edgar
* Cerron Tome Renzo


### To - Do 


- [x] HDFS connection
- [x] Heat Maps
- [x] Some queries 
- [ ] Dask
